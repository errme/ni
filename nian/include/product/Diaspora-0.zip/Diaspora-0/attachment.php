<?php get_template_part( '404' ); ?>
