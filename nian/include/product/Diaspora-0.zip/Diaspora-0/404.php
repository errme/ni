<?php get_header(); ?>
<div id="p404">
    <h2>Not Found</h2>
    <p>
        The page you were looking for is no longer available.
        <a href="/"> - Back Home -</a>
    </p>
</div>
