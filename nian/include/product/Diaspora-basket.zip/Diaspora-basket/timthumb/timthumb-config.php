<?php

define ('LIMIT_ON', TRUE);

define ('ALLOW_EXTERNAL', FALSE);

define ('BROWSER_CACHE_MAX_AGE', 86400000);

define ('DEFAULT_WIDTH', 680);

define ('DEFAULT_HEIGHT', 440);

define ('FILE_CACHE_DIRECTORY', './what');

define ('DISPLAY_ERROR_MESSAGES', FALSE);

?>
