<?php

define ('USE_TIMTHUMB', FALSE);

define ('LOGO_FONT', FALSE);

?>
