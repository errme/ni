<?php
define ('USE_TIMTHUMB', false);
define ('LOGO_FONT', false);
?>
