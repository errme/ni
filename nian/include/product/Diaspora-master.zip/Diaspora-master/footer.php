<script src="<?php echo get_template_directory_uri(); ?>/static/jquery.min.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/static/plugin.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/assets/Diaspora.js"></script>
<?php wp_footer(); ?>
</body>
</html>
